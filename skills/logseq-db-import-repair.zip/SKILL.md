---
name: logseq-db-import-repair
description: "Use when diagnosing or repairing Logseq 2.x DB graph imports or migrations, reviewing legacy tag-versus-backlink meaning, renderer crashes, duplicate or stranded entities, and suspected block corruption through the native Logseq MCP."
---

# Logseq DB import repair

This skill documents crash-causing corruption patterns found in graphs migrated from Logseq OG (file-based) to Logseq DB-native, how to diagnose them with the native Logseq MCP tools (no JS stack trace is available through this interface), and how to fix them while changing as little of the original document as possible.

## Guiding principle: repair, don't rebuild

The goal is always to keep the page's structure, wording, ordering and block UUIDs as close to the original as the tooling allows. Never respond to a crash by deleting and re-importing a page's content from scratch (`importPage(replace=true)` or similar). Instead:

- Use `updateBlock` to fix only the offending block's text in place, preserving its UUID, its position, and any properties (like `:logseq.property/heading`) that should survive.
- Use `removeBlock` only for blocks that are confirmed to be invisible junk (empty content, no legitimate purpose) — never for a block that has visible text, even if it's also part of the bug.
- Use `moveBlock` / `moveBlocks` to relocate content during diagnosis, never as the repair itself unless the goal is genuinely to reorganize.
- After any fix, re-read the affected UUIDs and relevant parent/heading/link state. `pageStats` and `findOrphans` are supplementary counts, not proof of content preservation or renderer recovery; confirm the UI symptom separately.

The native E2E checklist records no live passes. The historical crash examples
below are hypotheses to check against the current graph, not proof that a
current build reproduces them. Keep source contracts, automated fixtures and
actual UI checks distinct.

## Review legacy tags versus backlinks

Logseq OG often used tags and backlinks for similar mention or navigation purposes. In DB graphs they are different relations: a tag assigns a class/category to an entity and may declare properties or behavior; a backlink points to a specific page. Do not mechanically convert every `#tag` into a page link, or preserve every legacy tag as a DB tag.

The first task is a recommendation report, not a write. Review each use in context; the same tag name may be a classification in one block and a reference in another. Inspect imported blocks by UUID and compare candidate page/tag entities when available. Do not decide from spelling, capitalization, frequency, or tag counts alone.

### Inventory and report

1. Confirm the requested scope: named pages, an import batch, or a whole graph. Do not silently expand a page-level request into a graph-wide audit.
2. Read every in-scope block and record its UUID and surrounding heading/content. Identify `{{tag:Name}}` import placeholders separately from already-attached DB tag relations. For existing relations, inspect the tag with `getTag` and its holders with `getTagUsers`; do not confuse a text marker with a stored relation.
3. For each candidate name, check whether a unique page exists with `getPageUUID` and whether it is also an existing tag with `getTagUUID`. If placeholder names need a resolution preview, use `repairLinks(page_uuid=..., include_tags=true, dry_run=true)` and pair its name-level results with the block inventory; it does not report every occurrence location. `include_tags=true` processes every tag placeholder on that page, not selected names or blocks.
4. Produce the recommendation table below. Cite representative block UUIDs and enough surrounding text to show why each use is a classification or a page reference. If the same name serves both roles, split the recommendation by use. Do not convert merely because a matching page exists.

Recommend **convert to backlink** when the legacy marker refers to a specific page/concept/person/source and there is a unique intended page. Recommend **keep as tag** when it consistently classifies an entity (type, role, state, workflow, or reusable category), especially when the tag has declared properties or native behavior. Recommend **unclear** when the term is broad, context is insufficient, a name could mean either a category or a page, or page/tag titles collide.

Return a table with one row per meaning/use group, not just one row per tag name:

| Legacy tag/use | Example block UUIDs and context | Candidate page | Recommendation | Rationale | Confidence |
| --- | --- | --- | --- | --- | --- |

Keep ambiguous cases in `unclear`; ask the user. Do not modify content or relations until the user approves specific rows and destinations.

### Applying approved conversions

- Resolve the intended page with `getPageUUID` and inspect the exact tag with `getTagUUID`/`getTag` when needed. Stop if the page is missing, ambiguous, or conflicts with a tag title. Do not create a page unless the user separately approves page creation.
- For imported placeholder text, convert only approved occurrences from `{{tag:Name}}` to `{{link:Name}}` with `updateBlock`, preserving other occurrences and text. Before import, author approved page references as `[[Name]]`; `importPage` escapes them to link placeholders.
- Resolve approved link placeholders with `repairLinks(page_uuid=..., dry_run=true)` first. Its default `include_tags=false` processes links while leaving tag placeholders inert. Review exact resolved/missing/ambiguous results. A dry run intentionally returns `verified: false` because it writes nothing; assess its resolution results, not that flag. Leave `create_missing` off unless page creation is separately approved.
- Then run the scoped repair for approved links. Require `verified: true`, `blocks_updated`, and an empty `unverified` list; read back representative blocks and confirm the intended `refs`. If any block is unverified, inspect it before retrying.
- Do not run a write with `include_tags=true` until every tag placeholder on that page has a final approved `keep as tag` decision. The tool cannot restrict tag repair to selected names or blocks; any `unclear` placeholder would also be materialized. If decisions are mixed or unresolved, leave tag placeholders inert and report the limitation rather than repairing them page-wide.
- If the use is already a DB tag relation rather than placeholder text, treat relation removal separately: identify the exact target and tag UUID, obtain approval, add and repair the approved page-link placeholder, then remove only that relation with `removeTag`. Removing a tag relation alone does not create a backlink. Do not delete the tag definition globally; other entities may still depend on it.
- Convert per use, not globally by tag name. Afterward, read each affected block and check its link target; verify remaining tag relations and report any partial or ambiguous result. Never retry a timed-out write until state has been inspected.

## Known crash-causing patterns

Both patterns below were found in a graph migrated from Logseq OG. Both are silent at the data layer (writes succeed, `pageStats`/`findOrphans` show no damage) but crash the Logseq DB renderer with its generic "Something went wrong" error-boundary screen when the page is opened. A full app quit-and-relaunch may be needed to see a fix take effect if the renderer already crashed on that page in the current app session.

### Pattern 1 — a heading block whose entire content is a single wiki-link

Example: a block with content `# [[6a93617c-78e8-48fc-be23-5b64c897e648]]` (a level-1 heading) or `#### [[6a936179-74b2-43b5-a252-31e06f24880b]]` (level-4), where the bracketed link is the block's *only* content — no other text alongside it.

This crashed regardless of whether the link was self-referential (pointing at the page the block itself lives on) or pointed at an unrelated page (including a page that is itself an alias target). Self-reference is not required to trigger it — a plain heading-only link to any other page reproduced the crash too.

**Proposed fix after confirmation:** record the block's UUID, parent, order
and native heading property; then use `updateBlock` with plain descriptive
text. Do not prepend Markdown heading markers to preserve the level:
single-block update is not import's heading-conversion route. Re-read the
same UUID and verify text, parent, heading level and removal of the intended
reference. If any differs, stop rather than assuming preservation.

```
Before: {"content": "#### [[6a936179-74b2-43b5-a252-31e06f24880b]]", ":logseq.property/heading": 4, "refs": [{"id": 504}]}
After:  {"content": "Conflict", ":logseq.property/heading": 4}   # refs gone
```

If the information the link conveyed matters (e.g. it was providing a cross-reference), consider adding it back as a *non-heading* sibling or child block with a normal `[[link]]` — plain-content blocks with links elsewhere on the same page were tested extensively and never reproduced this crash. Only a heading block whose sole content is the link is implicated.

### Pattern 2 — an empty block carrying a raw `:block/link` attribute

These are blocks with `content: ""` (nothing visible in the UI) that nonetheless carry a `link` property — e.g. `getBlock` returns `{"content": "", "title": "", "link": {"id": 3130}}`. The referenced id is often a raw internal entity id that doesn't resolve to any block owned by the page in question — i.e. a dangling cross-page reference edge.

These are believed to be leftover artifacts from Logseq OG's `((block-reference))` / block-embed syntax: the display text was cleared out at some point during migration, but the underlying `:block/link` datascript edge was left behind, pointing at a block that may no longer exist in a form the DB renderer expects.

They were found as sole children of ordinary content blocks. That historical
shape is not a safe deletion rule: empty titles can be real embeds, and
children or references may carry meaningful information.

**Fix only after confirmation:** inspect the exact block, target, descendants
and references; obtain approval to remove a genuinely purposeless stub.
Pass the stub's UUID to `removeBlock`, never its visible parent or linked target.

**Guard against deleting a real embed.** The native Logseq MCP exposes
`listEmbeds` and returns embed target metadata from `getBlock`. Check the
suspect UUID in the owning page's embed listing first.
If it is a listed embed, it is a linked view, not an empty stub: preserve it
unless the user explicitly wants that embed removed. `removeBlock` must receive
the embed's UUID; its target remains intact. `listEmbeds` identifies embeds,
but is not a missing-target audit; use the structured inventory below for
suspected linked stubs. An empty title alone does
not prove the block is junk.

## Diagnostic method: bisection via non-destructive moves

There is no way to get a JS stack trace or crash log through the native MCP tools. When a page crashes and the cause isn't obviously one of the two patterns above, use binary-search bisection:

1. Create a disposable scratch page (`createPage`) to hold suspect content during testing. Never test destructively on the real page.
2. Create a landing block on the scratch page (`createBlock`), then move roughly half of the suspect page's top-level content there with `moveBlocks(..., placement="last-child")`. This preserves block UUIDs, content, and relative order — the move can always be reversed.
3. Ask the user to fully quit and relaunch the Logseq app (not just reopen the page/tab — a page that has already crashed the renderer once in the running app session may stay in a bad state even after the underlying data is fixed) and report whether the real page still crashes.
4. If it still crashes, the bad block is in the half that stayed — repeat the split on that half. If it stops crashing, the bad block was in the half you moved out — move that half back in smaller pieces and repeat.
5. Continue halving until a single block is isolated. Confirm by moving that one block back alone and re-testing, then moving it out again to confirm the crash toggles with its presence.
6. Once confirmed, apply the appropriate fix from the patterns above (don't leave it stranded on the scratch page).
7. Before merging bisected content back onto the real page, proactively scan it for Pattern 2 (see below) — a properties scan is cheap and catches other latent instances that bisection alone might not isolate quickly, since multiple bad blocks can coexist on one page.
8. When reassembling moved content, use `moveBlocks` again with the blocks sorted back into their *original* document order (capture original `:block/order` values before you start moving things, e.g. via `inspectPage(detail="blocks")`, so you can restore the original reading order rather than whatever order the scratch page's shuffling left them in).
9. Delete the scratch page once the real page is confirmed fixed and everything has been moved back.

## Proactively scanning a page for Pattern 2 before it causes a crash

`getProperyUsers` takes an exact namespaced property ident, not a UUID, title
or raw `"link"` attribute. Use `findEntities` for a bounded structured
inventory instead. Replace the example page UUID with the resolved page:

```json
{
  "kind": "block",
  "page_uuid": "00000000-0000-4000-8000-000000000001",
  "where": {
    "all": [
      {"field": "title", "op": "empty"},
      {"field": "has_link", "op": "eq", "value": true}
    ]
  },
  "select": ["uuid", "title", "parent_uuid"],
  "limit": 50
}
```

Check `truncated` and continue with `next_cursor` unchanged; graph writes
invalidate paging. `has_link` describes embed/link structure, not ordinary
textual backlinks or proof of a dangling target. Inspect each UUID with
`getBlock`, compare `listEmbeds`, and check descendants/references before
proposing a repair. This inventory grants no deletion permission.
